Essa extensão integra o Plesk com o Google DNS, então você pode:
- Sincronizar todos os registros das zonas de DNS entre o Plesk e o Google DNS de uma vez
- Enviar atualizações de DNS automaticamente para o Google DNS

### Atenção
Você precisa criar o domínio no [Google Console Platform](https://console.cloud.google.com/net-services/dns/zones/) para conseguir sincroniza-lo.

I espero poder melhorar essa extensão e poder também criar zonas automaticamente no Google DNS, você pode ajudar a melhorar essa extensão através do [repositório do github](https://github.com/spacedogcs/plesk-googledns) 